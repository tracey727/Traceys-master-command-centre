# GENEVIEVE™ Dog Park — Final Deploy Today

Upload only these files directly to a fresh GitHub repo root.

## Vercel settings

Framework Preset: Other  
Root Directory: ./  
Install Command: leave blank  
Build Command: leave blank  
Output Directory: leave blank or .

Do not upload old GENEVIEVE_DOGPARK folders. GitHub must show `index.html`, `styles.css`, `app.js`, and `vercel.json` at the top level.
